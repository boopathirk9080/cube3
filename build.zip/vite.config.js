// import { defineConfig } from 'vite'
// import react from '@vitejs/plugin-react'
// import tailwindcss from '@tailwindcss/vite'

// // https://vite.dev/config/
// export default defineConfig({
//   resolve: {
//     alias: {
//       "@": path.resolve(__dirname, "src"),
//     },
//   },
//   base: '',
//   build: {
//     outDir: 'build'  // Change this to 'build' if you want to use that folder.
//   },
//   plugins: [
//     tailwindcss(),
//     react()],
// })


import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'path'; // Import the path module

// https://vite.dev/config/
export default defineConfig({
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"), // Alias for the src directory
    },
  },
  base: '',
  build: {
    outDir: 'build', // Output directory for the build
  },
  plugins: [
    tailwindcss(),
    react(),
  ],
});