


// import React, { useState, useRef, useEffect } from "react";
// import { Link } from "react-router-dom";
// import { FiMenu, FiX } from "react-icons/fi";
// import logo from "../assets/logo/cube-events-logo.png";
// import { navlink } from "../data/data";

// const Header = () => {
//     const [isOpen, setIsOpen] = useState(false);
//     const headerRef = useRef(null);
//     const mobileNavRef = useRef(null);

//     const updateScrollPadding = () => {
//         const headerHeight = headerRef.current?.offsetHeight || 0;
//         const mobileNavHeight = mobileNavRef.current?.offsetHeight || 0;

//         // Calculate total height based on menu state
//         const totalHeight = isOpen ? headerHeight + mobileNavHeight : headerHeight;

//         document.documentElement.style.setProperty(
//             "--scroll-padding",
//             `${totalHeight + 15}px` // 15px buffer for better spacing
//         );
//     };

//     // Update padding on resize and menu state change
//     useEffect(() => {
//         updateScrollPadding();
//         window.addEventListener("resize", updateScrollPadding);
//         return () => window.removeEventListener("resize", updateScrollPadding);
//     }, [isOpen]);
//     const [activeLink, setActiveLink] = useState(""); // State to track the active link

//     return (
//         <header
//             /* shadow-md*/
//             className="bg-[#6b6b6b00] text-white   sticky top-0 w-full z-50"
//             ref={headerRef}
//         >
//             <div className="container mx-auto flex justify-between items-center py-4 px-10">
//                 <Link to="/" className="text-xl font-bold">
//                     <img src={logo} alt="Logo" className="h-10" />
//                 </Link>

//                 {/* Desktop Navigation */}
//                 <nav className="hidden md:flex space-x-10">
//                     {navlink.map((link, i) => (
//                         <a
//                             key={i}
//                             href={link.url}
//                             onClick={() => setActiveLink(link.url)} // Set the active link on click
//                             className={`px-4 py-2 rounded-md transition-all duration-300 ${activeLink === link.url
//                                 ? "bg-gray-950 text-white" // Active link styles
//                                 : "bg-[#606060] hover:bg-gray-800] hover:text-white"
//                                 }`}
//                         >
//                             {link.text}
//                         </a>
//                     ))}
//                 </nav>

//                 {/* Mobile Menu Toggle */}
//                 <button
//                     className="md:hidden"
//                     onClick={() => setIsOpen(!isOpen)}
//                     aria-expanded={isOpen}
//                     aria-label="Toggle navigation menu"
//                 >
//                     {isOpen ? <FiX size={30} /> : <FiMenu size={30} />}
//                 </button>
//             </div>

//             {/* Mobile Navigation */}
//             {isOpen && (
//                 <nav
//                     className="md:hidden bg-[#112240] rounded-b-lg absolute top-full left-0 w-full p-6 shadow-md"
//                     ref={mobileNavRef}
//                     data-aos="fade-up"
//                     data-aos-duration="200"
//                 >
//                     {navlink.map((link, i) => (
//                         <a
//                             key={i}
//                             href={link.url}
//                             className="block text-white py-2 text-lg text-center hover:text-blue-400 transition duration-300"
//                             onClick={() => setIsOpen(false)}
//                             aria-current={window.location.pathname === link.url ? "page" : undefined}
//                         >
//                             {link.text}
//                         </a>
//                     ))}
//                 </nav>
//             )}
//         </header>
//     );
// };

// export default Header;

import { FiMenu, FiX } from "react-icons/fi"; // Import React Icons
import { motion, AnimatePresence } from "framer-motion";
import { navLinks } from "../data/data";
import { useState } from "react";
import logo from "../assets/logo/cube-events-logo.png";

const Header = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [activeSection, setActiveSection] = useState("home");

    const drawerVariants = {
        closed: {
            x: "100%",
            transition: {
                type: "spring",
                damping: 20,
                when: "afterChildren",
                staggerChildren: 0.05,
                staggerDirection: -1,
            },
        },
        open: {
            x: 0,
            transition: {
                type: "spring",
                damping: 20,
                when: "beforeChildren",
                staggerChildren: 0.1,
            },
        },
    };

    const itemVariants = {
        closed: { x: 20, opacity: 0 },
        open: { x: 0, opacity: 1 },
    };

    const handleNavClick = (id) => {
        setActiveSection(id);
        setIsOpen(false); // Close the menu after clicking
    };

    return (
        <header className="bg-[#11111195] text-white sticky top-0 w-full z-50">
            {/* Top Section */}
            <div className="container mx-auto flex justify-between items-center py-4 px-6">
                <a href="/" className="text-xl font-bold">
                    <img src={logo} alt="Logo" className="h-10" />
                </a>
                <button
                    className="md:hidden text-2xl"
                    onClick={() => setIsOpen(!isOpen)}
                    aria-label="Toggle navigation menu"
                >
                    {isOpen ? <FiX size={30} /> : <FiMenu size={30} />}
                </button>
                <nav className="hidden md:flex space-x-6">
                    {navLinks.map((link) => (
                        <a
                            key={link.id}
                            href={link.path}
                            className={`py-2 px-4 rounded-md transition-all duration-300 relative ${activeSection === link.id
                                ? "text-[#ef4949]"
                                : "hover:text-[#ef4949] text-white"
                                }`}
                            onClick={() => handleNavClick(link.id)}
                        >
                            {link.title}
                            <span
                                className={`absolute left-0 bottom-0 w-full h-[2px] bg-[#ef4949] transform scale-x-0 transition-transform duration-300 ${activeSection === link.id ? "scale-x-100" : "hover:scale-x-100"
                                    }`}
                            ></span>
                        </a>
                    ))}
                </nav>
            </div>

            {/* Mobile Drawer */}
            <AnimatePresence mode="sync">
                {isOpen && (
                    <>
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="fixed inset-0 bg-[#11111195] bg-opacity-50 z-40"
                            onClick={() => setIsOpen(false)}
                        />
                        <motion.div
                            id="mobileMenu"
                            className="fixed top-0 right-0 h-full w-4/5 bg-[#111111] shadow-lg z-50"
                            variants={drawerVariants}
                            initial="closed"
                            animate="open"
                            exit="closed"
                        >
                            <div className="p-6">
                                <div className="flex justify-between items-center mb-8">
                                    <a href="/" className="text-xl font-bold">
                                        <img src={logo} alt="Logo" className="h-10" />
                                    </a>
                                    <button
                                        id="closeMenu"
                                        className="text-[#EEEEEE] text-2xl"
                                        onClick={() => setIsOpen(false)}
                                    >
                                        <FiX size={30} />
                                    </button>
                                </div>
                                <nav className="flex flex-col space-y-4">
                                    {navLinks.map((link) => (
                                        <motion.a
                                            key={link.id}
                                            href={link.path}
                                            className={`py-2 text-[#EEEEEE] hover:text-[#ef4949] transition-colors relative ${activeSection === link.id ? "text-[#ef4949]" : ""
                                                }`}
                                            onClick={() => handleNavClick(link.id)}
                                            variants={itemVariants}
                                            whileHover={{ x: 5 }}
                                        >
                                            {link.title}
                                            <span
                                                className={`absolute left-0 bottom-0 w-full h-[2px] bg-[#ef4949] transform scale-x-0 transition-transform duration-300 ${activeSection === link.id ? "scale-x-100" : "hover:scale-x-100"
                                                    }`}
                                            ></span>
                                        </motion.a>
                                    ))}
                                    <motion.button
                                        className="mt-4 bg-[#ef4949] hover:bg-opacity-90 text-[#EEEEEE] px-6 py-3 rounded-full font-semibold transition-all btn-glow"
                                        variants={itemVariants}
                                        whileTap={{ scale: 0.95 }}
                                    >
                                        Book Now
                                    </motion.button>
                                </nav>
                            </div>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>
        </header>
    );
};

export default Header;