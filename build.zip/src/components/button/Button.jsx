import React from 'react'
import './Button.css'
function Button() {
    return (
        <button class="button">
            <span class="button-content">Download </span>
        </button>

    )
}

export default Button