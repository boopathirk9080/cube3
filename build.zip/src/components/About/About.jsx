import React from 'react'
import About21 from './About21'
function About() {
  return (
    <div>
      <About21 />
    </div>
  )
}

export default About