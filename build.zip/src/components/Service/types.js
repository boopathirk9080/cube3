/**
 * @typedef {{ id: string, title: string, path: string }} NavLink
 */

/**
 * @typedef {Object} Service
 * @property {string} id
 * @property {string} title
 * @property {string} description
 * @property {string} icon
 * @property {string} image
 * @property {string} detailedDescription
 * @property {string[]} features
 * @property {string} pricing
 * @property {{ quote: string, author: string, position?: string }} [testimonial]
 */

/**
 * @typedef {{ id: string, title: string, image: string, category: string }} GalleryItem
 */

/**
 * @typedef {{ year: string, description: string }} TimelineItem
 */

/**
 * @typedef {{ value: string, label: string }} Stat
 */

/**
 * @typedef {Object} EventDetail
 * @property {string} id
 * @property {string} title
 * @property {string} subtitle
 * @property {string} description
 * @property {string} image
 * @property {string} date
 * @property {string} location
 * @property {string} category
 * @property {string[]} highlights
 * @property {number} [attendees]
 * @property {string} [ticketPrice]
 */

// Note: These typedefs are for documentation and tooling support in JS files. They do not emit runtime code.
