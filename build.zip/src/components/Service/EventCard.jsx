import PropTypes from 'prop-types';
import { Badge } from "./badge";
import { motion } from "framer-motion";
const EventCard = ({ event }) => {
    return (
        <motion.div
            className="bg-black rounded-xl overflow-hidden border border-[#222222] hover:border-[#ef4949] transition-all duration-300 h-full flex flex-col"
            whileHover={{ y: -5, rotateX: 1, rotateY: 1 }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
        >
            <div className="relative h-48 overflow-hidden">
                <img
                    src={event.image}
                    alt={event.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute top-4 left-4">
                    <Badge className="bg-[#ef4949] text-white">{event.category}</Badge>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-60"></div>
                <div className="absolute bottom-4 left-4 right-4">
                    <div className="flex justify-between items-center text-white">
                        <div className="bg-black bg-opacity-70 py-1 px-3 rounded-lg text-sm flex items-center">
                            <i className="fas fa-calendar-alt mr-2"></i>
                            {event.date}
                        </div>
                        <div className="bg-black bg-opacity-70 py-1 px-3 rounded-lg text-sm flex items-center">
                            <i className="fas fa-map-marker-alt mr-2"></i>
                            {event.location.split(' ')[0]}
                        </div>
                    </div>
                </div>
            </div>

            <div className="p-5 flex-grow flex flex-col">
                <h3 className="text-xl font-montserrat font-bold mb-1 text-white">{event.title}</h3>
                <p className="text-[#ef4949] font-medium text-sm mb-3">{event.subtitle}</p>
                <p className="text-[#DDDDDD] text-sm mb-4 line-clamp-3">{event.description}</p>

                <div className="mt-auto flex flex-wrap gap-2">
                    {event.highlights.slice(0, 2).map((highlight, index) => (
                        <div key={index} className="text-xs bg-[#222222] text-[#DDDDDD] py-1 px-2 rounded-md flex items-center">
                            <i className="fas fa-star text-[#ef4949] mr-1 text-[10px]"></i>
                            {highlight.length > 25 ? highlight.substring(0, 25) + '...' : highlight}
                        </div>
                    ))}
                </div>

                <div className="mt-4 pt-4 border-t border-[#222222] flex justify-between items-center">
                    {event.ticketPrice && (
                        <div className="text-[#EEEEEE]">
                            <span className="text-xs text-[#999999]">From</span>
                            <span className="ml-1 font-semibold">{event.ticketPrice.split(' - ')[0]}</span>
                        </div>
                    )}
                    <motion.button
                        className="text-[#ef4949] flex items-center text-sm font-medium"
                        whileHover={{ x: 3 }}
                        transition={{ type: "spring", stiffness: 300 }}
                    >
                        View Details <i className="fas fa-arrow-right ml-1"></i>
                    </motion.button>
                </div>
            </div>
        </motion.div>
    );
};

EventCard.propTypes = {
    event: PropTypes.shape({
        id: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
        subtitle: PropTypes.string.isRequired,
        description: PropTypes.string.isRequired,
        image: PropTypes.string.isRequired,
        date: PropTypes.string.isRequired,
        location: PropTypes.string.isRequired,
        category: PropTypes.string.isRequired,
        highlights: PropTypes.arrayOf(PropTypes.string).isRequired,
        ticketPrice: PropTypes.string,
    }).isRequired,
};

export default EventCard;
