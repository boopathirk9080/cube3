
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from '../src/components/home/Home'
import Header from './components/Nav/Header';
import Footer from "./components/footer/Footer";
import Gallery from "./components/gallary/Gallary";
// function App() {

//   return (
//     <>
//       <Router>
//         <Header />
//         <Home />
//         <Routes>
//           <Route path="/gallery" element={<Gallery />} />


//         </Routes>
//         <Footer />
//       </Router>

//     </>
//   )
// }
function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/gallery" element={<Gallery />} />
      </Routes>
      <Footer />
    </Router>
  )
}
export default App


